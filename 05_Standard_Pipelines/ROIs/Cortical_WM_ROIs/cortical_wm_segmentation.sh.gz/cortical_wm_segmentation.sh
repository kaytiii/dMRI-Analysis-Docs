# Cortical WM ROI split

cd /Users/kayti/Desktop/Projects/MIND/CorWM_Segmentation

# cortical WM - atlas
fslmaths HarvardOxford-sub-maxprob-thr0-1mm.nii -thr 1 -uthr 1 CorWM_left.nii
fslmaths HarvardOxford-sub-maxprob-thr0-1mm.nii -thr 12 -uthr 12 CorWM_right.nii
fslmaths CorWM_left.nii.gz -add CorWM_right.nii.gz CorWM.nii
# cortical WM - probability map
fslmaths HO_All.nii.gz -thr 90 HO_CorWM_thr_90.nii.gz 
fslmaths HO_CorWM_thr_90.nii.gz -bin HO_CorWM_thr_90_bin.nii.gz

gunzip *.nii.gz

# posterior
fslroi HO_CorWM_thr_90_bin.nii CorWM_posterior.nii 0 180 0 95 0 180   # second set of numbers are the crucial numbers

# posterior + mid 
fslroi HO_CorWM_thr_90_bin.nii CorWM_post_mid.nii 0 180 0 145 0 180  # second set of numbers are the crucial numbers


# reslice ROIs
flirt -in CorWM_posterior.nii -ref FMRIB58_FA_1mm.nii -out CorWM_posterior_r.nii
flirt -in CorWM_post_mid.nii -ref FMRIB58_FA_1mm.nii -out CorWM_post_mid_r.nii

gunzip *.nii.gz

# anterior 
fslmaths HO_CorWM_thr_90_bin.nii -sub CorWM_post_mid_r.nii CorWM_anterior.nii
fslmaths CorWM_anterior.nii -thr 1 CorWM_anterior_t.nii

# mid
fslmaths CorWM_post_mid_r.nii -sub CorWM_posterior_r.nii CorWM_mid.nii

gunzip *.nii.gz

cp CorWM_mid.nii CorWM_mid_final.nii
cp CorWM_anterior_t.nii CorWM_anterior_final.nii
cp CorWM_posterior_r.nii CorWM_posterior_final.nii

mkdir Intermediate
for f in CorWM_anterior_t CorWM_posterior_r CorWM_mid CorWM_posterior CorWM_post_mid_r CorWM_anterior CorWM_post_mid ; do
  mv ${f}.nii Intermediate/${f}.nii
done

