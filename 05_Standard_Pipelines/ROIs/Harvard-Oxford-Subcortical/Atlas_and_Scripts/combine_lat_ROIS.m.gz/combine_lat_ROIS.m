%% Combine H/O Subcortical Atlas L/R regions

roi_folder= '/Volumes/users/benitez_a/CamCAN/Scripts/ROIs/HO';
left_rois = dir(fullfile(roi_folder, '75_Left*'));
right_rois = dir(fullfile(roi_folder, '75_Right*'));

for i =1:length(left_rois)
[comb_rois(i).name] = strrep(left_rois(i).name, 'Left', 'Comb');
end

% for i=1:length(left_rois)
%     gunzip(fullfile(roi_folder, left_rois(i).name));
%         gunzip(fullfile(roi_folder, right_rois(i).name));
% end
% 
% jeezy = dir(fullfile(roi_folder, '*.nii.gz'));
% for j=1:length(jeezy)
% delete(fullfile(roi_folder, jeezy(j).name));
% end


for i=1:length(left_rois)
    l_hdr = spm_vol(fullfile(roi_folder,left_rois(i).name));
    l_img = spm_read_vols(l_hdr);
    r_hdr = spm_vol(fullfile(roi_folder,right_rois(i).name));
    r_img = spm_read_vols(r_hdr);
    comb_img = l_img + r_img;
    comb_img = comb_img>0;
    comb_hdr = l_hdr;
    comb_hdr.fname = fullfile(roi_folder, comb_rois(i).name);
    spm_write_vol(comb_hdr, comb_img);
end