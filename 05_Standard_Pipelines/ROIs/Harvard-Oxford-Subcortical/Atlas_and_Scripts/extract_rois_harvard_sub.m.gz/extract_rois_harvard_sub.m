
% roi_list = {'HarvardOxford-cort-maxprob-thr0-2mm.nii'};
% region_code_list = {{1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 18 19 20 21 22 23 24 25 26 27 28 29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47}};
% region_string_list = {{'Insular' 'SFG' 'MFG' 'IFG_pt' 'IFG_po' 'Precen' 'Temp_pol' 'STG_ant' 'STG_pos' 'MTG_ant' 'MTG_pos' 'MTG_temp' 'ITG_ant' 'ITG_pos' 'ITG_temp' 'Postcen' 'SP' 'SPG_ant' 'SPG_pos' 'Angul' 'Lat_Occ_sup' 'Lat_Occ_inf' 'Intracal' 'Front_Med' 'Supple_M' 'Subcall' 'Paracing' 'Cing_ant' 'Cing_pos' 'Precun' 'Cuneal' 'Front_Orb' 'Parahipp_ant' 'Parahipp_pos' 'Lingal' 'TF_ant' 'TF_pos' 'T_Occ' 'Occip_Fus' 'Front_Operc' 'Cent_Operc' 'Pariet_Operc' 'Plan' 'Heschl' 'Plan_Temp' 'Supracal' 'Occi_pol'}};

roi_list = {'HarvardOxford-sub-maxprob-thr0-1mm.nii'};
region_code_list = {{[3 14] [4 15] [5 16] [6 17] [8 18] [9 19] [10 20]}};
region_string_list = {{'Thal' 'Cauda' 'Put' 'Pal' 'Hippo' 'Amyg' 'Accumb'}};

img_folder = '/Volumes/users/benitez_a/CamCAN/Scripts/ROIs';

for i = 1:length(roi_list)
    
    for j = 1:length(region_code_list{i})
        
                  
            % read roi image
            
            fn = fullfile(img_folder, [roi_list{i}]);
            
            hdr = spm_vol(fn);        
            img = spm_read_vols(hdr);   
            
            % binarize img
            
            if isscalar(region_code_list{i}{j})     % if region code is a scalar
                img = img == region_code_list{i}{j};
            else                                    % if region code is a vector
                tmp = img == region_code_list{i}{j}(1);
                for ii = 2:length(region_code_list{i}{j})
                    tmp = tmp | (img == region_code_list{i}{j}(ii));
                end
                img = tmp;
            end               
            
                     
        % write output
        hdr.fname = fullfile(img_folder, [region_string_list{i}{j} '.nii']);
        spm_write_vol(hdr, img);
    end
end
       
            
       
        
        

